import React from "react";

const Bye = () => {
    return(
        <h1>
            Bye Bye!
        </h1>
    );
}

export default Bye;