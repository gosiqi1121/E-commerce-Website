import '../LogIn/login.css'
import SignBar from '../SignBar/SignBar'
import Login from './LogIn'

const LoginScreen = () => {

    return (
        <>
            <SignBar/>
            <Login />
        </>
    )
}
export default LoginScreen